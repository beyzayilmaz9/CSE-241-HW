#include "board.h"

int main() {
    Board chess_board;
    chess_board.play();

    return 0;
}