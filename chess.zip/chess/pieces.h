#ifndef PIECES_H
#define PIECES_H

class Pieces {
private:
    char name, position_x;
    int point, position_y;
    char color; 
    bool is_empty, in_danger;

public:
    Pieces();
    Pieces(char piece_name, int piece_point, char piece_x, int piece_y, char piece_color);
    void set_position(char coor_x, int coor_y);
    char get_coordinates_x() const;
    int get_coordinates_y() const;
    char get_name() const;
    bool isEmpty() const;
    char get_color() const;
    char get_point() const;
    void set_color(char col);
    void set_empty();
    void set_not_empty();
    Pieces operator=(const Pieces &other);
    void set_danger(bool value);
    bool get_danger() const;
};

#endif 
