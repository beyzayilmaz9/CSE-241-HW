#include "board.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

struct possibleBoard
{
    Board b1;
    double score;
    string move;
};

Board::Board()
{
    board.resize(8, vector<Pieces>(8));
    /*rook*/
    Pieces R_W_1('R', 5, 'a', 1, 'w');
    Pieces R_W_2('R', 5, 'h', 1, 'w');
    Pieces R_B_1('R', 5, 'a', 8, 'b');
    Pieces R_B_2('R', 5, 'h', 8, 'b');
    /*knight*/
    Pieces N_W_1('N', 3, 'b', 1, 'w');
    Pieces N_W_2('N', 3, 'g', 1, 'w');
    Pieces N_B_1('N', 3, 'b', 8, 'b');
    Pieces N_B_2('N', 3, 'g', 8, 'b');
    /*bishop*/
    Pieces B_W_1('B', 3, 'c', 1, 'w');
    Pieces B_W_2('B', 3, 'f', 1, 'w');
    Pieces B_B_1('B', 3, 'c', 8, 'b');
    Pieces B_B_2('B', 3, 'f', 8, 'b');
    /*king*/
    Pieces K_W('K', 0, 'e', 1, 'w');
    Pieces K_B('K', 0, 'e', 8, 'b');
    /*queen*/
    Pieces Q_W('Q', 9, 'd', 1, 'w');
    Pieces Q_B('Q', 9, 'd', 8, 'b');
    /*pawn*/
    Pieces P_W_1('P', 1, 'a', 2, 'w');
    Pieces P_W_2('P', 1, 'b', 2, 'w');
    Pieces P_W_3('P', 1, 'c', 2, 'w');
    Pieces P_W_4('P', 1, 'd', 2, 'w');
    Pieces P_W_5('P', 1, 'e', 2, 'w');
    Pieces P_W_6('P', 1, 'f', 2, 'w');
    Pieces P_W_7('P', 1, 'g', 2, 'w');
    Pieces P_W_8('P', 1, 'h', 2, 'w');

    Pieces P_B_1('P', 1, 'a', 7, 'b');
    Pieces P_B_2('P', 1, 'b', 7, 'b');
    Pieces P_B_3('P', 1, 'c', 7, 'b');
    Pieces P_B_4('P', 1, 'd', 7, 'b');
    Pieces P_B_5('P', 1, 'e', 7, 'b');
    Pieces P_B_6('P', 1, 'f', 7, 'b');
    Pieces P_B_7('P', 1, 'g', 7, 'b');
    Pieces P_B_8('P', 1, 'h', 7, 'b');

    add_piece(R_W_1);
    add_piece(R_W_2);
    add_piece(R_B_1);
    add_piece(R_B_2);

    add_piece(N_W_1);
    add_piece(N_W_2);
    add_piece(N_B_1);
    add_piece(N_B_2);

    add_piece(B_W_1);
    add_piece(B_W_2);
    add_piece(B_B_1);
    add_piece(B_B_2);

    add_piece(K_W);
    add_piece(K_B);
    add_piece(Q_W);
    add_piece(Q_B);

    add_piece(P_W_1);
    add_piece(P_W_2);
    add_piece(P_W_3);
    add_piece(P_W_4);
    add_piece(P_W_5);
    add_piece(P_W_6);
    add_piece(P_W_7);
    add_piece(P_W_8);

    add_piece(P_B_1);
    add_piece(P_B_2);
    add_piece(P_B_3);
    add_piece(P_B_4);
    add_piece(P_B_5);
    add_piece(P_B_6);
    add_piece(P_B_7);
    add_piece(P_B_8);
}

void Board::add_piece(const Pieces &piece)
{
    char i = piece.get_coordinates_x();
    int k = 'h' - i;
    int j = piece.get_coordinates_y();
    --j;
    board[j][k] = piece;
}

Pieces Board::get_board_element(char p_x, int p_y)
{
    int column = 'h' - p_x;
    int row = p_y - 1;
    return board[row][column];
}

Board Board::operator=(const Board &other)
{
    if (this != &other){
        for (int i = 0; i < 8; ++i){
            for (int j = 0; j < 8; ++j){
                board[i][j] = Pieces();
            }
        }

        for (int i = 0; i < 8; ++i){
            for (int j = 0; j < 8; ++j){
                board[i][j] = other.board[i][j];
            }
        }
    }

    return *this;
}

void Board::printBoard()
{
    char first = 'a';
    for (int i = 7; i >= 0; --i){
        cout << i + 1 << " | ";
        for (int j = 7; j >= 0; --j){
            if (board[i][j].isEmpty()){
                cout << ".  ";
            }
            else
            {
                if (board[i][j].get_color() == 'b')
                    cout << (char)tolower(board[i][j].get_name()) << "  ";
                else if (board[i][j].get_color() == 'w')
                    cout << board[i][j].get_name() << "  ";
            }
        }
        cout << endl;
    }
    cout << "    -----------------------" << endl
         << "    ";
    for (int i = 0; i < 8; ++i){
        cout << (char)(first + i) << "  ";
    }
    cout << endl;
}

bool Board::isValidMove(char piece_x, char piece_y, char dest_x, char dest_y, bool white_turn){

    if (piece_x < 'a' || piece_x > 'h' || piece_y < '1' || piece_y > '8' || dest_x < 'a' || dest_x > 'h' || dest_y < '1' || dest_y > '8')
        return false;

    if (get_board_element(piece_x, piece_y - '0').isEmpty())
        return false;

    if (white_turn){
        if (get_board_element(piece_x, piece_y - '0').get_color() == 'b' || get_board_element(dest_x, dest_y - '0').get_color() == 'w'){
            return false;
        }
    }
    else{
        if (get_board_element(piece_x, piece_y - '0').get_color() == 'w' || get_board_element(dest_x, dest_y - '0').get_color() == 'b')
            return false;
    }

    char min, max, startX, endX;
    int startY, endY;
    switch (get_board_element(piece_x, piece_y - '0').get_name())
    {
    case 'R':
        if ((piece_x == dest_x && piece_y != dest_y)){
            min = (piece_y < dest_y) ? piece_y : dest_y;
            max = (piece_y > dest_y) ? piece_y : dest_y;

            for (int i = min - '0' + 1; i <= max - '1'; i++){
                if (!get_board_element(piece_x, i).isEmpty()){
                    return false;
                }
            }
            return true;
        }

        if ((piece_x != dest_x && piece_y == dest_y)){
            min = (piece_x < dest_x) ? piece_x : dest_x;
            max = (piece_x > dest_x) ? piece_x : dest_x;

            for (int i = min - 'a' + 1; i <= max - 'a' - 1; i++){
                if (!get_board_element(i + 'a', piece_y - '0').isEmpty()){
                    return false;
                }
            }
            return true;
        }

        break;
    case 'B':
        if (abs(piece_x - dest_x) != abs(piece_y - dest_y))
            return false;
        startX = (piece_x < dest_x) ? piece_x : dest_x;
        startY = (piece_y < dest_y) ? piece_y - '0' : dest_y - '0';
        endX = (piece_x < dest_x) ? dest_x : piece_x;
        endY = (piece_y < dest_y) ? dest_y - '0' : piece_y - '0';

        for (int i = 1; i < abs(piece_x - dest_x); i++){
            if (!get_board_element(startX + i, startY + i).isEmpty()){
                return false;
            }
        }
        return true;
        break;
    case 'N':
        if (abs(piece_x - dest_x) == 2 && abs(piece_y - dest_y) == 1 || abs(piece_x - dest_x) == 1 && abs(piece_y - dest_y) == 2)
            return true;
        break;
    case 'Q':
        if ((piece_x == dest_x && piece_y != dest_y)){
            min = (piece_y < dest_y) ? piece_y : dest_y;
            max = (piece_y > dest_y) ? piece_y : dest_y;

            for (int i = min - '0' + 1; i <= max - '1'; i++){
                if (!get_board_element(piece_x, i).isEmpty()){
                    return false;
                }
            }
            return true;
        }

        if ((piece_x != dest_x && piece_y == dest_y)){
            min = (piece_x < dest_x) ? piece_x : dest_x;
            max = (piece_x > dest_x) ? piece_x : dest_x;

            for (int i = min - 'a' + 1; i <= max - 'a' - 1; i++){
                if (!get_board_element(i + 'a', piece_y - '0').isEmpty())
                {
                    return false;
                }
            }
            return true;
        }

        if (abs(piece_x - dest_x) == abs(piece_y - dest_y)){
            startX = (piece_x < dest_x) ? piece_x : dest_x;
            startY = (piece_y < dest_y) ? piece_y - '0' : dest_y - '0';
            endX = (piece_x < dest_x) ? dest_x : piece_x;
            endY = (piece_y < dest_y) ? dest_y - '0' : piece_y - '0';

            for (int i = 1; i < abs(piece_x - dest_x); i++){
                if (!get_board_element(startX + i, startY + i).isEmpty())
                {
                    return false;
                }
            }
            return true;
        }
        break;
    case 'K':
        if (piece_x == dest_x && abs(piece_y - dest_y) == 1 || abs(piece_x - dest_x) == 1 && piece_y == dest_y || abs(piece_x - dest_x) == 1 && abs(piece_y - dest_y) == 1)
            return true;
        break;
    case 'P':
        if (get_board_element(piece_x, piece_y - '0').get_color() == 'b'){
            if (dest_y - piece_y == -1 && piece_x == dest_x)
                if (get_board_element(dest_x, dest_y - '0').isEmpty())
                    return true;
            if (piece_y == '7')
                if (dest_y - piece_y == -2 && piece_x == dest_x)
                    if (get_board_element(dest_x, dest_y - '0').isEmpty())
                        return true;
            if (piece_y - dest_y == 1 && abs(piece_x - dest_x) == 1 && !get_board_element(dest_x, dest_y - '0').isEmpty())
                return true;
        }
        else{
            if (dest_y - piece_y == 1 && piece_x == dest_x)
                if (get_board_element(dest_x, dest_y - '0').isEmpty())
                    return true;
            if (dest_y - piece_y == 1 && abs(piece_x - dest_x) == 1 && !get_board_element(dest_x, dest_y - '0').isEmpty())
                return true;
            if (piece_y == '2'){
                if (dest_y - piece_y == 2 && piece_x == dest_x)
                    if (get_board_element(dest_x, dest_y - '0').isEmpty())
                        return true;
            }
        }
        break;
    default:
        return false;
    }
    return false;
}

bool Board::attackPawn(char piece_x, char piece_y, char dest_x, char dest_y){
    if (get_board_element(piece_x, piece_y - '0').get_color() == get_board_element(dest_x, dest_y - '0').get_color())
        return false;
    if (get_board_element(piece_x, piece_y - '0').get_color() == 'b'){
        if (piece_y - dest_y == 1 && abs(piece_x - dest_x) == 1 && !get_board_element(dest_x, dest_y - '0').isEmpty())
            return true;
    }
    else{
        if (dest_y - piece_y == 1 && abs(piece_x - dest_x) == 1 && !get_board_element(dest_x, dest_y - '0').isEmpty())
            return true;
    }

    return false;
}

void Board::safety_check(){
    for (int m = 0; m < 8; m++){
        for (int n = 0; n < 8; n++){
            board[m][n].set_danger(false);
        }
    }

    for (int i = 1; i <= 8; i++){
        for (char j = 'a'; j <= 'h'; j++){
            if (!get_board_element(j, i).isEmpty()){
                if (get_board_element(j, i).get_name() == 'P'){
                    for (int k = 1; k <= 8; k++){
                        for (char l = 'a'; l <= 'h'; l++){
                            if (!get_board_element(l, k).isEmpty()){
                                if (attackPawn(j, i + '0', l, k + '0')){
                                    board[k - 1]['h' - l].set_danger(true);
                                }
                            }
                        }
                    }
                }
                else{
                    for (int destY = 1; destY <= 8; destY++){
                        for (char destX = 'a'; destX <= 'h'; destX++){
                            if (!get_board_element(destX, destY).isEmpty() && get_board_element(destX, destY).get_color() != get_board_element(j, i).get_color()){
                                if (isValidMove(destX, destY + '0', j, i + '0', get_board_element(destX, destY).get_color() == 'w')){
                                    get_board_element(destX, destY).set_danger(true);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

double Board::calculateScore(char col){
    double overallScore = 0;

    for (char i = 'a'; i <= 'h'; i++){
        for (int j = 1; j <= 8; j++){
            Pieces currentPiece = get_board_element(i, j);

            if (!currentPiece.isEmpty() && (currentPiece.get_color()) == col){
                int pieceScore = currentPiece.get_point();

                if (currentPiece.get_danger()){
                    pieceScore -= pieceScore / 2;
                }

                overallScore += pieceScore;
            }
        }
    }

    return overallScore;
}

double Board::calculateOverallGoodnessScore(char col){
    double overallScore = 0;
    double score_w= calculateScore('w');
    double score_b= calculateScore('b');
    if(col=='w'){
        overallScore= score_w-score_b;
    }
    else{
        overallScore= score_b-score_w;
    }
    return overallScore;
}

void Board::saveGame(const std::string &filename) const{
    ofstream file(filename, ios_base::app);
    if (!file.is_open()){
        std::cerr << "Error opening file for saving." << std::endl;
        return;
    }
    file << "***********************************" << endl;
    char first = 'a';
    for (int i = 7; i >= 0; --i){
        file << i + 1 << " | ";
        for (int j = 7; j >= 0; --j){
            if (board[i][j].isEmpty()){
                file << ".  ";
            }
            else{
                if (board[i][j].get_color() == 'b')
                    file << (char)tolower(board[i][j].get_name()) << "  ";
                else if (board[i][j].get_color() == 'w')
                    file << board[i][j].get_name() << "  ";
            }
        }
        file << std::endl;
    }
    file << "    -----------------------" << std::endl
         << "    ";
    for (int i = 0; i < 8; ++i){
        file << (char)(first + i) << "  ";
    }
    file << endl;

    file.close();
}

void Board::loadGame(const string &filename){
    ifstream file(filename);
    if (!file.is_open()){
        cerr << "Error opening file for loading." << endl;
        return;
    }

    string line;
    while (getline(file, line)){
        if (line == "***********************************"){
            for (int i = 8; i >= 0; --i){
                getline(file, line); 
                cout << line << endl;
            }
            getline(file, line); // Read the line with column labels
            cout << line << endl;
        }
        cout << endl;
    }

    file.close();
}

Board Board::nextMove(bool white_turn, string &move){
    vector<possibleBoard> possibleMoves;

    char col = white_turn ? 'w' : 'b';

    for (int i = 1; i <= 8; i++)
    {
        for (char j = 'a'; j <= 'h'; j++)
        {
            if (!get_board_element(j, i).isEmpty() && get_board_element(j, i).get_color() == col)
            {
                for (int destY = 1; destY <= 8; destY++)
                {
                    for (char destX = 'a'; destX <= 'h'; destX++)
                    {
                        if (isValidMove(j, i + '0', destX, destY + '0', white_turn))
                        {
                            Board tempBoard = *this; 
                            tempBoard.board[i - 1]['h' - j].set_empty();
                            tempBoard.board[destY - 1]['h' - destX].set_empty();
                            tempBoard.board[destY - 1]['h' - destX].set_not_empty();
                            tempBoard.board[destY - 1]['h' - destX].set_position(destY, 'h' - destX);
                            tempBoard.board[destY - 1]['h' - destX].set_color(col);
                            string currentMove = j + to_string(i) + destX + to_string(destY);
                            possibleMoves.push_back({tempBoard, tempBoard.calculateOverallGoodnessScore(col), currentMove});
                        }
                    }
                }
            }
        }
    }

    if (possibleMoves.empty()){//no valid move
        return *this;
    }

    //find the move with the highest score
    double maxScore = possibleMoves[0].score;
    int maxIndex = 0;
    for (size_t i = 1; i < possibleMoves.size(); i++){
        if (possibleMoves[i].score > maxScore)
        {
            maxScore = possibleMoves[i].score;
            maxIndex = i;
        }
    }
    move = possibleMoves[maxIndex].move;
    return possibleMoves[maxIndex].b1;
}

void Board::suggest(bool white_turn){
    Board newBoard;
    string move;
    if (white_turn){
        newBoard = nextMove(true, move);
    }
    else{
        newBoard = nextMove(false, move);
    }
    cout << "Suggestion is: " << move << endl;
}

bool Board::move(bool white_turn, bool game){
    string input;
    while (true){
        cout << "Enter your move: ";
        cin >> input;
        if (input == "suggest"){
            suggest(white_turn);
        }
        else if (input == "point"){
            double point_w = calculateScore('w');
            double point_b = calculateScore('b');
            cout << fixed << setprecision(1);
            cout << "White's Point: " << point_w << endl;
            cout << "Black's Point: " << point_b << endl;
        }
        else if (input == "load"){
            loadGame("chess.txt");
        }
        else{
            char piece_x = input[0];
            char piece_y = input[1];
            char dest_x = input[2];
            char dest_y = input[3];
            if (isValidMove(piece_x, piece_y, dest_x, dest_y, white_turn)){
                if (board[(dest_y - '0') - 1]['h' - dest_x].get_name() == 'K'){
                    game = false;
                }
                board[(piece_y - '0') - 1]['h' - piece_x].set_empty();
                board[(dest_y - '0') - 1]['h' - dest_x] = board[(piece_y - '0') - 1]['h' - piece_x];
                board[(piece_y - '0') - 1]['h' - piece_x].set_color('e');
                board[(dest_y - '0') - 1]['h' - dest_x].set_not_empty();
                board[(dest_y - '0') - 1]['h' - dest_x].set_position(dest_y - '0', 'h' - dest_x);
                saveGame("chess.txt");
                break;
            }
            else{
                cout << "Invalid move. Please enter a valid move." << endl;
            }
        }
    }

    return game;
}

void Board::play(){
    ofstream filen("chess.txt", ios_base::out);
    if (!filen.is_open()){
        std::cerr << "Error opening file for saving." << std::endl;
        return;
    }
    filen.close();
    bool game = true;
    bool white_turn = true;
    cout << "Welcome to the Chess Game!" << endl;
    while (game){
        if (white_turn){
            printBoard();
            cout << "[White's Turn]" << endl;
            game = move(white_turn, game);
            if (game == false){
                cout << "White wins!";
                cout << "GAME OVER" << endl;
            }
            safety_check();
            white_turn = false;
        }
        else{
            printBoard();
            cout << "[Black's Turn]" << endl;
            game =move(false, game);
            if (game == false){
                cout << "Black wins!";
                cout << "GAME OVER" << endl;
            }
            safety_check();
            white_turn = true;
        }
    }
    return ;
}







