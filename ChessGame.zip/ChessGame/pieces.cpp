#include "pieces.h"

Pieces::Pieces() : point(0), is_empty(true), in_danger(false), name('e') {}

Pieces::Pieces(char piece_name, int piece_point, char piece_x, int piece_y, char piece_color)
    : name(piece_name), point(piece_point), position_x(piece_x), position_y(piece_y),
      color(piece_color), is_empty(false), in_danger(false) {}

void Pieces::set_position(char coor_x, int coor_y) {
    position_x = coor_x;
    position_y = coor_y;
}

char Pieces::get_coordinates_x() const {
    return position_x;
}

int Pieces::get_coordinates_y() const {
    return position_y;
}

char Pieces::get_name() const {
    return name;
}

bool Pieces::isEmpty() const {
    return is_empty;
}

char Pieces::get_color() const {
    return color;
}

char Pieces::get_point() const {
    return point;
}

void Pieces::set_color(char col) {
    color = col;
}

void Pieces::set_empty() {
    is_empty = true;
}

void Pieces::set_not_empty() {
    is_empty = false;
}

Pieces Pieces::operator=(const Pieces &other) {
    name = other.name;
    point = other.point;
    color = other.color;
    is_empty = other.is_empty;
    position_x = other.position_x;
    position_y = other.position_y;
    return *this;
}

void Pieces::set_danger(bool value) {
    in_danger = value;
}

bool Pieces::get_danger() const {
    return in_danger;
}
