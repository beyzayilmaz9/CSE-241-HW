#ifndef BOARD_H
#define BOARD_H

#include <vector>
#include <string>

#include "pieces.h"

class Board {
private:
    std::vector<std::vector<Pieces>> board; // x<y>

public:
    Board();
    void add_piece(const Pieces &piece);
    Pieces get_board_element(char i, int j);
    void printBoard();
    bool move(bool white_turn, bool game_over);
    bool isValidMove(char piece_x, char piece_y, char dest_x, char dest_y, bool white_turn);
    void safety_check();
    bool attackPawn(char piece_x, char piece_y, char dest_x, char dest_y);
    double calculateOverallGoodnessScore(char col);
    double calculateScore(char col);
    Board nextMove(bool white_turn, std::string &move);
    void saveGame(const std::string &filename) const;
    void loadGame(const std::string &filename);
    void suggest(bool white_turn);
    Board operator=(const Board &other);
    void play();
};

#endif 
