#include "iterators.h"
#include "file.h"
namespace MyFileSystem {

// Iterator for RegularFile
RegularFileIterator::RegularFileIterator(const std::vector<RegularFile*>& regularFiles)
    : files(regularFiles), currentIndex(0) {}

File* RegularFileIterator::next() {
    if (hasNext()) {
        RegularFile* currentFile = files[currentIndex++];
        currentBytes = currentFile->get_content();
        return currentFile;
    }
    return nullptr;
}

bool RegularFileIterator::hasNext() const {
    return currentIndex < files.size();
}

std::string RegularFileIterator::getCurrentBytes() const {
    return currentBytes;
}

// Iterator for SoftLinkedFile
SoftLinkedFileIterator::SoftLinkedFileIterator(const std::vector<SoftLinkedFile*>& softLinkedFiles)
    : linkedFiles(softLinkedFiles), currentIndex(0) {}

File* SoftLinkedFileIterator::next() {
    if (hasNext()) {
        SoftLinkedFile* currentFile = linkedFiles[currentIndex++];
        currentBytes = currentFile->get_content();
        return currentFile;
    }
    return nullptr;
}

bool SoftLinkedFileIterator::hasNext() const {
    return currentIndex < linkedFiles.size();
}

std::string SoftLinkedFileIterator::getCurrentBytes() const {
    return currentBytes;
}

// Iterator for Directory
DirectoryIterator::DirectoryIterator(const std::vector<File*>& files)
    : contents(files), currentIndex(0) {}

File* DirectoryIterator::next() {
    if (hasNext()) {
        return contents[currentIndex++];
    }
    return nullptr;
}

bool DirectoryIterator::hasNext() const {
    return currentIndex < contents.size();
}

}