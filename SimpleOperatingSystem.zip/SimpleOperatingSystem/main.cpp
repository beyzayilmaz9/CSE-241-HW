#include <iostream>
#include <sstream>
#include "file.h"
#include "utilityFunctions.h"

#define OS_SIZE 1048576
using namespace MyFileSystem;
int File::totalSize = 0;

template <typename T>
void deleteObjectsInVector(std::vector<T*>& vec) {
    for (T* obj : vec) {
        delete obj;
    }
    vec.clear();  
}

int main() {
    std::cout<<"To get info about commands use info command."<<std::endl;
    std::cout<<std::endl<<"myShell"<<std::endl;
    Directory* root= new Directory("root");
    root->set_directory(nullptr);
    std::string input, input2, input3,input4,token;
    std::vector<RegularFile*> VECT_RF;
    std::vector<SoftLinkedFile*> VECT_SLF;
    std::vector<Directory*> VECT_D;
    VECT_D.clear();
    VECT_RF.clear();
    VECT_SLF.clear();
    VECT_D.push_back(root);
    loadFromFile(VECT_RF, VECT_SLF,VECT_D);
    Directory* current = VECT_D[0];
    std::string command[4];
    int i;
    while(command[0]!="exit"){
        for(int i=0;i<4;++i)
            command[i]="";
        std::cout<<"> ";
        std::getline(std::cin, input);
        std::istringstream iss(input);
        std::string token;
        i=0;
        while (std::getline(iss, token, ' ')) {
            command[i]=token;
            i++;
        }

        if(command[0]=="ls"&& command[1]=="")//works
            current->ls();
        else if(command[0]=="ls" && command[1]=="-R")//works
            current->ls_r();
        else if (command[0] == "mkdir") {//works
            if(current->get_totalSize()+1024 < OS_SIZE){
            Directory* d = new Directory(command[1]);
            d->set_directory(current);
            VECT_D.push_back(d);
            current->mkdir(d);
            }
            else
                std::cout<<"There's no enough space for that."<<std::endl;
        }
        else if(command[0]=="cd" && command[1]=="..")
            current= root;
        else if(command[0]=="cd")//works
            current= current->cd(command[1]);
        else if(command[0]=="cat"){
            File* ptr;
            ptr=current->find_file(command[1]);
            if(ptr)
                ptr->cat();
            else
                std::cout<<"Error: Invalid source file for cat." << std::endl;
        }
        else if(command[0]=="rm"){//works
            File* ptr= current->find_file(command[1]);
            ptr->rm();
        }
        else if(command[0]=="cp" && command[1]=="-OS"){
            std::string path=command[2];
            File* destination=current->find_file(command[3]);
            if (RegularFile* dptr = dynamic_cast<RegularFile*>(destination) ){
                        dptr->cp_from_os(path);
                }
            else    
                std::cout<<"Invalid source file."<<std::endl;

        }
        else if(command[0]=="cp"){//works
            File* source=current->find_file(command[1]);
            File* destination=current->find_file(command[2]);
            if(source->get_exist()){
                if (Directory* dptr = dynamic_cast<Directory*>(destination) ){
                        dptr->cp(source);
                }
                else{
                    if(Directory* sptr = dynamic_cast<Directory*>(source))
                        std::cout<<"Invalid input."<<std::endl;
                    else
                        destination->cp(source);
                }
            }
        }
        else if (command[0] == "ln" && command[1] == "-S") {
            File* source = current->find_file(command[2]);
            if(source){
                RegularFile* rptr = dynamic_cast<RegularFile*>(source);
                if (rptr == nullptr) 
                    std::cout << "Error: Invalid source file for linking." << std::endl;
                else {
                    SoftLinkedFile* s = new SoftLinkedFile(command[3]);
                    s->set_directory(current);
                    s->link(rptr);
                    current->addEntry(s);
                    VECT_SLF.push_back(s);

            }}
        }
        else if(command[0]=="touch"){//works
            RegularFile* d = new RegularFile(command[1]);
            d->set_directory(current);
            VECT_RF.push_back(d);
            current->addEntry(d);
        }
        else if(command[0]=="info"){
            std::cout<<"[INFO]"<<std::endl;
            std::cout<<"-ls"<<std::endl;
            std::cout<<"-ls -R"<<std::endl;
            std::cout<<"-mkdir directory-name"<<std::endl;
            std::cout<<"-cd directory-name"<<std::endl;
            std::cout<<"-cd .."<<std::endl;
            std::cout<<"-cat regularFile/softLinkedFile"<<std::endl;
            std::cout<<"-rm regularFile/softLinkedFile/directory(removes only if drectory empty)"<<std::endl;
            std::cout<<"-cp source destination"<<std::endl;
            std::cout<<"-cp -OS source(path) destination"<<std::endl;
            std::cout<<"-ln -S source linkedfilenmae "<<std::endl;
            std::cout<<"-touch regularFile"<<std::endl;
            std::cout<<"-exit"<<std::endl;
        }
        else if(command[0]!="exit")
            std::cout<<"Invalid output."<<std::endl;

    }
    saveToFile(VECT_RF, VECT_SLF,VECT_D);
    deleteObjectsInVector(VECT_RF);
    deleteObjectsInVector(VECT_SLF);
    deleteObjectsInVector(VECT_D);

    return 0;
}
