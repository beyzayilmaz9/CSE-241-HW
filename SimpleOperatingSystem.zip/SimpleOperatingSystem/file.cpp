// File.cpp
#include "file.h"

namespace MyFileSystem {

// File class
void File::set_totalSize(int _size) {
    totalSize = _size;
}

int File::get_totalSize() {
    return totalSize;
}

void File::set_exist(bool value) {
    exist = value;
}

void File::set_name(std::string _name) {
    name = _name;
}

void File::set_name_empty() {
    name.clear();
}

void File::set_size(int _size) {
    size = _size;
    set_totalSize(get_totalSize() + _size);
}

void File::set_directory(File* d) {
    parent = d;
}

void File::set_date(const std::string& _date) {
    date = _date;
}

void File::updateDate() {
    std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
    std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
    struct std::tm* localTime = std::localtime(&currentTime);
    
    // Manually format the date string
    char buffer[20];
    std::strftime(buffer, sizeof(buffer), "%b %d %H:%M", localTime);
    
    date = buffer;
}


std::string File::getDate() const {
    return date;
}

// RegularFile class
RegularFile::RegularFile() {}

RegularFile::RegularFile(const std::string& _name) {
    set_exist(true);
    set_size(0);
    updateDate();
    set_name(_name);
}

void RegularFile::cat() const {
    std::cout << fileContent << std::endl;
}

void RegularFile::rm() {
    fileContent.clear();
    set_size(0);
    set_totalSize(get_totalSize() - get_size());
    set_name_empty();
    set_exist(false);
}

void RegularFile::cp(File* ptr) {
    fileContent = ptr->get_content();
}

std::string RegularFile::get_content() const {
    return fileContent;
}

void RegularFile::echo(const std::string& _content) {
    fileContent = _content;
    set_size(sizeof(fileContent));
}

void RegularFile::cp_from_os(const std::string& os_path) {
    std::ifstream os_file(os_path, std::ios::binary);
    if (os_file) {
        std::ostringstream buffer;
        buffer << os_file.rdbuf();
        std::string content = buffer.str();

        // Update the file content
        echo(content);

        std::cout << "File copied from OS: " << os_path << " -> " << get_name() << std::endl;
    } else {
        std::cout << "Error: Unable to open file in the OS: " << os_path << std::endl;
    }
}

// SoftLinkedFile class
SoftLinkedFile::SoftLinkedFile(const std::string& _name) {
    set_name(_name);
    set_exist(true);
    updateDate();
}

std::string SoftLinkedFile::get_content() const {
    return source->get_content();
}

bool SoftLinkedFile::get_source_exist() const {
    return source->get_exist();
}

std::string SoftLinkedFile::get_source_name() const {
    return source->get_name();
}

void SoftLinkedFile::link(RegularFile* r) {
    if (r != nullptr) {
        source = r;
        set_size(r->get_size());
    } else
        std::cout << "Error: Cannot link to a null source." << std::endl;
}

void SoftLinkedFile::set_source(RegularFile* r) {
    if (r != nullptr) {
        source = r;
    } else
        std::cout << "Error: Cannot link to a null source." << std::endl;
}

void SoftLinkedFile::cat() const {
    source->cat();
}

void SoftLinkedFile::rm() {
    set_totalSize(get_totalSize() - get_size());
    source = nullptr;
    set_name_empty();
    set_exist(false);
}

void SoftLinkedFile::cp(File* ptr) {
    echo(ptr->get_content());
}

void SoftLinkedFile::echo(const std::string& _content) {
    source->echo(_content);
}

void SoftLinkedFile::cp_from_os(const std::string& os_path) {
    std::ifstream os_file(os_path, std::ios::binary);
    if (os_file) {
        std::ostringstream buffer;
        buffer << os_file.rdbuf();
        std::string content = buffer.str();

        // Update the file content
        echo(content);

        std::cout << "File copied from OS: " << os_path << " -> " << get_name() << std::endl;
    } else {
        std::cout << "Error: Unable to open file in the OS: " << os_path << std::endl;
    }
}

// Directory class
Directory::Directory(const std::string& name) {
    set_exist(true);
    set_directory(nullptr);
    set_name(name);
    updateDate();
    set_size(1024);
}

void Directory::cat() const {}

void Directory::cp(File* ptr) {
    if (Directory* dptr = dynamic_cast<Directory*>(ptr))
        contents = dptr->get_contents();
    else
        std::cout << "You can only copy directory with directory." << std::endl;
}

void Directory::echo(const std::string& _content) {}

std::string Directory::get_content() const {
    return "aaa";
}

std::vector<File*> Directory::get_contents() const {
    return contents;
}

void Directory::rm() {
    if (!contents.empty()) { // ERROR
        std::cout << "Directory has contents. Can not be removed." << std::endl;
        return;
    }
    set_size(0);
    set_totalSize(get_totalSize() - get_size());
    set_name_empty();
    set_exist(false);
}

void Directory::addEntry(File* entry) {
    contents.push_back(entry);
}

void Directory::ls() const {
    for (File* ptr : contents) {
        if (ptr->get_exist()) {
            if (RegularFile* rptr = dynamic_cast<RegularFile*>(ptr)) {
                std::cout << " F " << rptr->get_name() << "           " << rptr->getDate() << "           " << rptr->get_size() << std::endl;
            } else if (SoftLinkedFile* rptr = dynamic_cast<SoftLinkedFile*>(ptr)) {
                if (rptr->get_source_exist())
                    std::cout << " L " << rptr->get_name() << "           " << rptr->getDate() << std::endl;
            } else if (Directory* rptr = dynamic_cast<Directory*>(ptr)) {
                std::cout << " D " << rptr->get_name() << "           " << rptr->getDate() << std::endl;
            }
        }
    }
}

void Directory::ls_r() const {
    std::cout << ".:" << std::endl;
    ls();
    for (File* ptr : contents) {
        if (ptr->get_exist()) {
            if (Directory* rptr = dynamic_cast<Directory*>(ptr)) {
                std::cout << rptr->get_name() << ":" << std::endl;
                rptr->ls();
            }
        }
    }
}

void Directory::mkdir(Directory* d1) {
    addEntry(d1);
}

File* Directory::find_file(const std::string& _name) {
    for (File* ptr : contents) {
        if (ptr->get_name() == _name)
            return ptr;
    }
    return nullptr;
}

Directory* Directory::cd(const std::string& dirName) {
        for(File* ptr: contents){
            if(Directory* dp= dynamic_cast<Directory*>(ptr)){
                if(dp->get_name()==dirName)
                    return dp;
            }
        }
        std::cout<<"There is no dictionary has this name in this dictionary."<<std::endl;
        return &(*this);
    }

}
