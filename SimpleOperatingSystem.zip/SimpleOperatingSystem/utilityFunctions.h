#pragma once
#ifndef UTILITYFUNCTIONS_H
#define UTILITYFUNCTIONS_H
#include <vector>
#include <fstream>

namespace MyFileSystem {

class RegularFile;
class SoftLinkedFile;
class Directory;

void saveToFile(std::vector<RegularFile*>& regularFiles,
                std::vector<SoftLinkedFile*>& softLinkedFiles,
                std::vector<Directory*>& directories);

void loadFromFile(std::vector<RegularFile*>& regularFiles,
                  std::vector<SoftLinkedFile*>& softLinkedFiles,
                  std::vector<Directory*>& directories);
}
#endif
