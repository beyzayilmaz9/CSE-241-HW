// Iterators.hpp
#pragma once
#ifndef ITERATORS_H
#define ITERATORS_H
#include "file.h"
namespace MyFileSystem {
class FileIterator {
public:
    virtual File* next() = 0;
    virtual bool hasNext() const = 0;
    virtual ~FileIterator() = default;
};

class RegularFileIterator : public FileIterator {
private:
    const std::vector<RegularFile*>& files;
    size_t currentIndex;
    std::string currentBytes;

public:
    RegularFileIterator(const std::vector<RegularFile*>& regularFiles);
    File* next() override;
    bool hasNext() const override;
    std::string getCurrentBytes() const;
};

class SoftLinkedFileIterator : public FileIterator {
private:
    const std::vector<SoftLinkedFile*>& linkedFiles;
    size_t currentIndex;
    std::string currentBytes;

public:
    SoftLinkedFileIterator(const std::vector<SoftLinkedFile*>& softLinkedFiles);
    File* next() override;
    bool hasNext() const override;
    std::string getCurrentBytes() const;
};

class DirectoryIterator : public FileIterator {
private:
    const std::vector<File*>& contents;
    size_t currentIndex;

public:
    DirectoryIterator(const std::vector<File*>& files);
    File* next() override;
    bool hasNext() const override;
};
}
#endif