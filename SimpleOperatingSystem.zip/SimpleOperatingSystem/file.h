// File.h
#pragma once
#ifndef FILE_H
#define FILE_H
#include <string>
#include <vector>
#include <chrono>
#include <ctime>    
#include <iomanip>
#include <iostream>
#include <sstream> 
#include <fstream> 

namespace MyFileSystem {
class File {
public:
    virtual void cat() const = 0;
    virtual void rm() = 0;
    virtual void cp(File* ptr) = 0;
    virtual ~File() = default;
    virtual std::string get_content() const = 0;
    virtual void echo(const std::string& _content) = 0;
    int get_size() const { return size; }
    File* get_parent() const { return parent; }
    void set_totalSize(int _size);
    static int get_totalSize();
    std::string get_name() const { return name; }
    void set_exist(bool value);
    bool get_exist() const { return exist; }
    void set_name(std::string _name);
    void set_name_empty();
    void set_size(int _size);
    void set_directory(File* d);
    void set_date(const std::string& _date);
    void updateDate();
    std::string getDate() const;

private:
    bool exist;
    int size;
    std::string date;
    static int totalSize;
    std::string name;
    File* parent;
};

class RegularFile : public File {
private:
    std::string fileContent;

public:
    RegularFile();
    RegularFile(const std::string& _name);

    void cat() const override;
    void rm() override;
    void cp(File* ptr) override;
    std::string get_content() const override;
    void echo(const std::string& _content) override;

    void cp_from_os(const std::string& os_path);
};

class SoftLinkedFile : public File {
private:
    RegularFile* source;

public:
    SoftLinkedFile(const std::string& _name);

    std::string get_content() const override;
    bool get_source_exist() const;
    std::string get_source_name() const;
    void link(RegularFile* r);
    void set_source(RegularFile* r);
    void cat() const override;
    void rm() override;
    void cp(File* ptr) override;
    void echo(const std::string& _content) override;

    void cp_from_os(const std::string& os_path);
};

class Directory : public File {
private:
    std::vector<File*> contents;

public:
    Directory(const std::string& name);
    void cat() const override;
    void cp(File* ptr) override;
    void echo(const std::string& _content) override;
    std::string get_content() const override;
    std::vector<File*> get_contents() const;
    void rm() override;

    void addEntry(File* entry);
    void ls() const;
    void ls_r() const;
    void mkdir(Directory* d1);
    File* find_file(const std::string& _name);
    Directory* cd(const std::string& dirName);
};

}
#endif
