#include "file.h"
#include "utilityFunctions.h"

#include <iostream>
#include <fstream>
namespace MyFileSystem {

template <typename T>
void deleteObjectsInVector(std::vector<T*>& vec) {
    for (T* obj : vec) {
        delete obj;
    }
    vec.clear();  
}

void saveToFile(std::vector<RegularFile*>& regularFiles,
                std::vector<SoftLinkedFile*>& softLinkedFiles,
                std::vector<Directory*>& directories) {

    std::ofstream outStream;
    outStream.open("filesystem.txt");
    if (!outStream.is_open()) {
        std::cerr << "Error: Could not open filesystem.txt for writing." << std::endl;
        return;
    }

    RegularFile f;
    outStream << "TotalSize" << std::endl << f.get_totalSize() << std::endl;

    for (const auto& dir : directories) {
        outStream << "DIR" << std::endl << dir->get_name() << std::endl << dir->getDate() << std::endl;
        if (dir->get_parent() != nullptr)
            outStream << dir->get_parent()->get_name() << std::endl;
        else
            outStream << "null" << std::endl;
    }

    for (const auto& rd : regularFiles) {
        outStream << "RF" << std::endl << rd->get_name() << std::endl << rd->get_size() << std::endl << rd->getDate() << std::endl;
        if (rd->get_parent() != nullptr) {
            outStream << rd->get_parent()->get_name() << std::endl;
        } else {
            outStream << "null" << std::endl;
        }
        if (!rd->get_content().empty())
            outStream << rd->get_content() << std::endl;
        else
            outStream << "empty file" << std::endl;
    }

    for (const auto& slf : softLinkedFiles) {
        outStream << "SLF" << std::endl << slf->get_name() << std::endl << slf->get_size() << std::endl
                  << slf->getDate() << std::endl << slf->get_parent()->get_name() << std::endl << slf->get_source_name() << std::endl;
    }

    outStream.close();
}

void loadFromFile(std::vector<RegularFile*>& regularFiles,
                  std::vector<SoftLinkedFile*>& softLinkedFiles,
                  std::vector<Directory*>& directories) {

    std::ifstream inStream;
    inStream.open("filesystem.txt");
    if (!inStream.is_open()) {
        std::cerr << "Error opening file. " << std::endl;
        return;
    }

    std::string fileContents;
    std::string line;
    int num = 0;
    std::getline(inStream, line);
    inStream >> num;
    RegularFile r;
    r.set_totalSize(num);
    while (std::getline(inStream, line)) {
        if (line == "DIR") {
            std::string name, date, parent;
            std::getline(inStream, name);
            std::getline(inStream, date);
            std::getline(inStream, parent);
            if (name != "root") {
                Directory* d = new Directory(name);

                d->set_date(date);
                for (const auto& directory : directories) {
                    if (directory->get_name() == parent) {
                        directory->addEntry(d);
                        d->set_directory(directory);
                    }
                }
                directories.push_back(d);
            }
        } else if (line == "RF") {
            std::string name, date, parent, content;
            int size = 0; // name size date parent content
            std::getline(inStream, name);
            RegularFile* d = new RegularFile(name);
            inStream >> size;
            std::getline(inStream, date);
            d->set_size(size);
            std::getline(inStream, date);
            std::getline(inStream, parent);
            std::getline(inStream, content);
            d->set_date(date);
            d->echo(content);
            for (const auto& directory : directories) {
                if (directory->get_name() == parent) {
                    directory->addEntry(d);
                    d->set_directory(directory);
                }
            }
            regularFiles.push_back(d);
        } else if (line == "SLF") { // name size date parent source
            std::string name, date, parent, source;
            int size; //
            std::getline(inStream, name);
            SoftLinkedFile* d = new SoftLinkedFile(name);
            inStream >> size;
            d->set_size(size);
            std::getline(inStream, date);
            std::getline(inStream, date);
            std::getline(inStream, parent);
            std::getline(inStream, source);
            d->set_date(date);
            for (const auto& directory : directories) {
                if (directory->get_name() == parent) {
                    directory->addEntry(d);
                    d->set_directory(directory);
                }
            }
            for (const auto& regular : regularFiles) {
                if (regular->get_name() == source) {
                    d->link(regular);
                }
            }
            softLinkedFiles.push_back(d);
        }
    }
    inStream.close();
}

}