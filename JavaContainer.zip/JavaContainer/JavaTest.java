import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;

public class JavaTest {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to JavaContainer Test!");
        System.out.println("Choose a container type:");
        System.out.println("1. JavaSet");
        System.out.println("2. JavaVector");

        int containerChoice = getUserChoice(scanner, 1, 2);
        int type = 0;
        JavaContainer<?> container;
        if (containerChoice == 1) {
            container = createSet(scanner,type);
        } else {
            container = createVector(scanner,type);
        }

        System.out.println("Container created." );

        // Perform operations
        performOperations(scanner, container,type);
        saveToFile(container, containerChoice);
        scanner.close();
    }

    private static JavaContainer<String> createSet(Scanner scanner,int type) {
        System.out.println("You've chosen to create a JavaSet.");
        System.out.println("Choose element type:");
        System.out.println("1. String");
        System.out.println("2. Integer");
        System.out.println("3. Double");
        System.out.println("4. Character");

        type = getUserChoice(scanner, 1, 4);

        JavaContainer<String> container = createContainerOfType(type);

        System.out.print("Enter the first element: ");
        String firstElement = scanner.next();
        container.add(firstElement);

        return container;
    }

    private static JavaContainer<Integer> createVector(Scanner scanner, int type) {
        System.out.println("You've chosen to create a JavaVector.");
        System.out.println("Choose element type:");
        System.out.println("1. String");
        System.out.println("2. Integer");
        System.out.println("3. Double");
        System.out.println("4. Character");

        type = getUserChoice(scanner, 1, 4);


        return createContainerOfType(type);
    }

    private static <T> JavaContainer<T> createContainerOfType(int elementTypeChoice) {
        switch (elementTypeChoice) {
            case 1:
                return new JavaSet<>();
            case 2:
                return new JavaVector<>();
            // Add more cases for other element types if needed
            default:
                throw new IllegalArgumentException("Invalid element type choice.");
        }
    }

    
    private static <T> void performOperations(Scanner scanner, JavaContainer<T> container, int type) {
        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Add Element");
            System.out.println("2. Remove Element");
            System.out.println("3. Quit");
    
            int operationChoice = getUserChoice(scanner, 1, 3);
    
            if (operationChoice == 1) {
                System.out.print("Enter element to add: ");
                T element = readInput(scanner, type);
                container.add(element);
                System.out.println("Element added.");
            } else if (operationChoice == 2) {
                System.out.print("Enter element to remove: ");
                T element = readInput(scanner, type);
                container.remove(element);
                System.out.println("Element removed.");
            } else {
                break; // Quit the loop
            }
            }
    }
    

private static <T> T readInput(Scanner scanner, int type) {
    System.err.println("Type: " + type);
    T input = null;
    String userInput;

    // Prompt user for input
    System.out.print("Enter element to add: ");

    try {
        userInput = scanner.next();

        if (type == 1) {
            // Handle String input
            input = (T) userInput;
        } else if (type == 0) {
            // Handle Integer input
            input = (T) Integer.valueOf(userInput);
        } else if (type == 3) {
            // Handle Double input
            input = (T) Double.valueOf(userInput);
        } else if (type == 4) {
            // Handle Character input
            if (userInput.length() == 1) {
                input = (T) Character.valueOf(userInput.charAt(0));
            } else {
                throw new InputMismatchException("Invalid character input.");
            }
        } else {
            // Add support for other types as needed
            throw new IllegalArgumentException("Unsupported element type.");
        }
    } catch (InputMismatchException | NumberFormatException e) {
        System.out.println("Invalid input. Using the default value.");
        scanner.nextLine(); // consume the invalid input
    }

    return input;
}


    private static int getUserChoice(Scanner scanner, int min, int max) {
        int choice;
        while (true) {
            System.out.print("Enter your choice: ");
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                if (choice >= min && choice <= max) {
                    break;
                } else {
                    System.out.println("Invalid choice. Please enter a number between " + min + " and " + max + ".");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next(); // Consume invalid input
            }
        }
        return choice;
    }

    private static <T> void saveToFile(JavaContainer<T> container, int containerChoice) {
        String fileName;

        if (containerChoice == 1) {
            fileName = "sets.txt";
        } else {
            fileName = "vectors.txt";
        }

        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(container.toString() + "\n");
            System.out.println("Elements saved to " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving elements to file: " + e.getMessage());
        }
    }
}
