import java.util.Iterator;
import java.util.NoSuchElementException;
public class JavaVector<T> implements JavaContainer<T> {
    private Object[] array;
    private int size;

    public JavaVector() {
        array = new Object[20];
        size = 0;
    }

    @Override
    public void add(T element) {
        if (size == array.length) {
            Object[] newArray = new Object[array.length * 2];
            System.arraycopy(array, 0, newArray, 0, array.length);
            array = newArray;
        }
        array[size++] = element;
    }

    @Override
    public void remove(T element) {
        for (int i = 0; i < size; i++) {
            if (array[i].equals(element)) {
                System.arraycopy(array, i + 1, array, i, size - i - 1);
                array[--size] = null;
                break;
            }
        }
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    //getIterator() method
    public Iterator<T> getIterator() {
        return new Iterator<T>() {
            private int currentIndex = 0;

            @Override
            public boolean hasNext() {
                return currentIndex < size;
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                return (T) array[currentIndex++];
            }

            public T current() {
                if (currentIndex >= size) {
                    throw new NoSuchElementException();
                }
                return (T) array[currentIndex];
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException("Remove operation is not supported.");
            }
        };
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("JavaVector: [");
        for (int i = 0; i < size; i++) {
            sb.append(array[i]);
            if (i != size - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        JavaVector<?> javaVector = (JavaVector<?>) obj;
        if (size != javaVector.size) return false;
        for (int i = 0; i < size; i++) {
            if (!array[i].equals(javaVector.array[i])) {
                return false;
            }
        }
        return true;
    }
}
