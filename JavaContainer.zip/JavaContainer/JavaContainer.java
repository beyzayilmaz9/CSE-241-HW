
import java.util.Iterator;

public interface JavaContainer<T> {
    void add(T element);
    void remove(T element);
    int size();
    public Iterator<T> getIterator() ;

}
