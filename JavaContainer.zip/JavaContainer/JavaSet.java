import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Iterator;


public class JavaSet<T> implements JavaContainer<T> {
    private static final int INITIAL_CAPACITY = 20;
    private Object[] elements;
    private int size;

    public JavaSet() {
        this.elements = new Object[INITIAL_CAPACITY];
        this.size = 0;
    }

    @Override
    public void add(T element) {
        if (!contains(element)) {
            ensureCapacity();
            elements[size++] = element;
        }
    }

    @Override
    public void remove(T element) {
        int index = indexOf(element);
        if (index != -1) {
            // Move elements to fill the gap
            System.arraycopy(elements, index + 1, elements, index, size - index - 1);
            elements[--size] = null;  // Clear the last element
        }
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    //getIterator() method
    public Iterator<T> getIterator() {
        return new Iterator<T>() {
            private int currentIndex = 0;

            @Override
            public boolean hasNext() {
                return currentIndex < size;
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                return (T) elements[currentIndex++];
            }

            public T current() {
                if (currentIndex >= size) {
                    throw new NoSuchElementException();
                }
                return (T) elements[currentIndex];
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException("Remove operation is not supported.");
            }
        };
    }
    @Override
    public String toString() {
        return "JavaSet: " + Arrays.toString(Arrays.copyOf(elements, size));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        JavaSet<?> javaSet = (JavaSet<?>) obj;
        return Arrays.equals(Arrays.copyOf(elements, size), Arrays.copyOf(javaSet.elements, javaSet.size));
    }


    private boolean contains(T element) {
        return indexOf(element) != -1;
    }

    

    private int indexOf(T element) {
        for (int i = 0; i < size; i++) {
            if (elements[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    private void ensureCapacity() {
        if (size == elements.length) {
            elements = Arrays.copyOf(elements, elements.length * 2);
        }
    }
}
